package com.example.demo;


import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@RestController
public class ProductController {

    @RequestMapping(value = "/sortProducts", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Product> sortProducts(@RequestBody ProductList productList){

        List<Product> products = (List<Product>) productList.getProductList().stream().sorted(new Comparator2()).collect(Collectors.toList());
        products = (List<Product>) productList.getProductList().stream().sorted(new CustomComparator()).collect(Collectors.toList());
        Collections.reverse(products);
        return products;
    }
}
